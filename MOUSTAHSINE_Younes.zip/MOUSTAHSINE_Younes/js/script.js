let parentClicks = 0;
/*let childClicks = 0;*/

document.getElementById("parent").addEventListener("click", function() {

  document.getElementById("parent-count").innerText = ++parentClicks;
});




document.getElementById("btn").addEventListener("click", function(e) {
  
  e.preventDefault();
  e.stopPropagation();
  
  parentClicks = 0;
   
  
  document.getElementById("parent-count").innerText = parentClicks;
});



let parent2Clicks = 0;
/*let childClicks = 0;*/

document.getElementById("parent2").addEventListener("click", function() {

  document.getElementById("parent2-count").innerText = ++parent2Clicks;
});



document.getElementById("btn2").addEventListener("click", function(e) {
  
  e.preventDefault();
  e.stopPropagation();
  
  parent2Clicks = 0;
   
 
  document.getElementById("parent2-count").innerText = parent2Clicks;
});





let parent3Clicks = 0;
/*let childClicks = 0;*/

document.getElementById("parent3").addEventListener("click", function() {

  document.getElementById("parent3-count").innerText = ++parent3Clicks;
});



document.getElementById("btn3").addEventListener("click", function(e) {
  
  e.preventDefault();
  e.stopPropagation();
  
  parent3Clicks = 0;
   
 
  document.getElementById("parent3-count").innerText = parent3Clicks;
});





let parent4Clicks = 0;
/*let childClicks = 0;*/

document.getElementById("parent4").addEventListener("click", function() {

  document.getElementById("parent4-count").innerText = ++parent4Clicks;
});



document.getElementById("btn4").addEventListener("click", function(e) {
  
  e.preventDefault();
  e.stopPropagation();
  
  parent4Clicks = 0;
   
 
  document.getElementById("parent4-count").innerText = parent4Clicks;
});



let parent5Clicks = 0;
/*let childClicks = 0;*/

document.getElementById("parent5").addEventListener("click", function() {

  document.getElementById("parent5-count").innerText = ++parent5Clicks;
});



document.getElementById("btn5").addEventListener("click", function(e) {
  
  e.preventDefault();
  e.stopPropagation();
  
  parent5Clicks = 0;
   
 
  document.getElementById("parent5-count").innerText = parent5Clicks;
});




let parent6Clicks = 0;
/*let childClicks = 0;*/

document.getElementById("parent6").addEventListener("click", function() {

  document.getElementById("parent6-count").innerText = ++parent6Clicks;
});



document.getElementById("btn6").addEventListener("click", function(e) {
  
  e.preventDefault();
  e.stopPropagation();
  
  parent6Clicks = 0;
   
 
  document.getElementById("parent6-count").innerText = parent6Clicks;
});